/**
 * arraySumUsingThread
 */
class Test extends Thread
{

  static int sum;
  int a;
  public void run()
  {
    //System.out.println("a:"+a);
    sum+=a;
   // System.out.println("sum:"+sum);
    /*for(int i = 0; i < 10; i++)
    {
      sum += i;
    }*/
  }
  
}
public class arraySumUsingThread
{
  public static void main(String args[])
  {
    Test test[] = new Test[5];  
    int ar[]={1,2,3,4,5};
    for(int i = 0; i < test.length; i++)
     {
       test[i] = new Test();
       test[i].a=ar[i];
       test[i].run();
       
      // test[i].a=ar[i];
     }
     System.out.println("Sum = " + Test.sum);
  }
}